<template>
  <UApp>
    <NuxtLayout>
      <NuxtPage />
    </NuxtLayout>
  </UApp>
</template>

<style>
:root {
  --font-sans: 'Montserrat', sans-serif;
}
</style>
