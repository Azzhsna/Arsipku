/// <reference types="@nuxtjs/i18n" />
/// <reference types="@nuxt/ui" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="@nuxt/devtools" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="C:/Projects/Arsipku/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
