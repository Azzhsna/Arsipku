export default {
  "base": "lg:hidden",
  "variants": {
    "side": {
      "left": "",
      "right": ""
    }
  }
}