export default {
  "slots": {
    "base": "",
    "trailing": "hidden lg:flex items-center gap-0.5 ms-auto"
  }
}