export default {
  "base": "mt-8 pb-24 space-y-12"
}