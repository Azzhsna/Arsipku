export default {
  "base": "fixed inset-0 flex overflow-hidden"
}