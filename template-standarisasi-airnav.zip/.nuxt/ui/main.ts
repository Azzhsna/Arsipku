export default {
  "base": "min-h-[calc(100vh-var(--ui-header-height))]"
}